/*18. Calculate person�s Annual salary*/

#include<stdio.h>
main()

{
	
	int person,salary,annualsalary;
	
	printf("Enter the person:");
	scanf("%d", &person);
	
	printf("Enter the salary:");
	scanf("%d", &salary);
	
	annualsalary =12*person*salary;
	 
	printf("Annual Salary:%d", annualsalary);
		
	}
