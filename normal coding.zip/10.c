/*10. find the area of a rectangular prism formula : A=2(wl+hl+hw) */

#include<stdio.h>
main()

{
	int w,h,l,A;
	
	printf("Enter the value of width:");
	scanf("%d", &w);
	printf("Enter the value of height:");
	scanf("%d", &h);
	printf("Enter the value of lenght:");
	scanf("%d", &l);
	
	A=w*l+h*l+h*w;
	
	printf("rectangular prism formula:%d",A);
}
