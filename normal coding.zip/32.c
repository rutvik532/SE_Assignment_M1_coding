/*32. Accept 2 numbers and find out its sum check it size */

#include<stdio.h>
main()
{
	
	int a,b,c;
	
	printf("Enter the value of a:");
	scanf("%d", &a);
	printf("Enter the value of b:");
	scanf("%d", &b);
	c=a+b;
	
	printf("Summation:%d", c);
	
	printf("\nvariable c size:%dbytes", sizeof(c));
	
}
