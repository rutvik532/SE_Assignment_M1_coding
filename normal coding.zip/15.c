/*15. Convert school�s name in abbreviated form*/

#include<stdio.h>
main()

	{
		char str[30];
		
		printf("Enter the school name:");
		gets(str);
		
		printf("abbreviated form: %c.%c", str[0], str[5]);
		
		
		
			}
