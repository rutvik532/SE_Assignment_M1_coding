/*25. Accept 5 expense from user and find average of expense*/

#include<stdio.h>
main()

{
	int expense1,expense2,expense3,expense4,expense5,averageexpense;
	
	
	
	
	
	printf("Enter expense1:");
	scanf("%d", &expense1);
	
	printf("Enter expense2:");
	scanf("%d", &expense2);
	
	printf("Enter expense3:");
	scanf("%d", &expense3);
	
	printf("Enter expense4:");
	scanf("%d", &expense4);
	
	printf("Enter expense5:");
	scanf("%d", &expense5);
	
	averageexpense=(expense1+expense2+expense3+expense4+expense5)/5;
	
	printf("\nAverage expense:%d",averageexpense);
	
	
}
