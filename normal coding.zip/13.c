/*13. Find character value from ascii */
#include<stdio.h>
main ()

{
	
	int a;
	printf("Enter the any number for ascii value:");
	scanf("%d", &a);
	
	printf("ascii value of input number:%c", a);
	
}
