/*4. Find Area of Square formula : a = a2 */
#include<stdio.h>
main()
{
	int a=25;
	int A=a*a;
	printf("a=25");
		printf("\nArea of square=%d", A);
	
	}
