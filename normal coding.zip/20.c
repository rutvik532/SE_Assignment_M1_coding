/*20. Accept monthly salary from the user and deduct 10% insurance premium, 
10% loan installment find out of remaining salary. */


#include<stdio.h>
main()

{
	
	int salary,deductedsalary,annualaveragesalary;
	
	printf("Enter monthly salary:");
	scanf("%d", &salary);
	
	deductedsalary=(salary-(salary*10/100)-(salary*10/100));

	annualaveragesalary= deductedsalary*12;
	
	printf("Annual average salary:%d", annualaveragesalary);
	
	
	
}
