/*31. Convert kilometers into meters  */

#include<stdio.h>
main()

{
	
	double kilometers,meters;
	
	printf("Enter the kilometers:");
	scanf("%lf", &kilometers);
	
	meters=kilometers*1000;
	
	printf("Meters:%.2lfm.", meters);
	
	
}
