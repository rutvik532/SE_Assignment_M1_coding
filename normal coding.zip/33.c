/*33. C Program to Read Integer and Print First Three Powers (N^1, N^2, N^3)*/

