/*24. Accept 5 employees name and salary and count average and total salary  */

#include<stdio.h>
main()

{
	
	char name1[30],name2[30],name3[30],name4[30],name5[30];
	int salary1,salary2,salary3,salary4,salary5,averagesalary,totalsalary;
	
	printf("Enter employee1 name:");
	gets(name1);
	
	printf("Enter employee2 name:");
	gets(name2);
	
	printf("Enter employee3 name:");
	gets(name3);
	
	printf("Enter employee4 name:");
	gets(name4);
	
	printf("Enter employee5 name:");
	gets(name5);
	
	puts("----------------------------------------------------------");
	
	puts(name1);
	puts(name2);
	puts(name3);
	puts(name4);
	puts(name5);
	
	printf("\n-----------------------------------------------------------");
	printf("\nEnter Employee1 monthly salary:");
	scanf("%d", &salary1);
	printf("Enter Employee2 monthly salary:");
	scanf("%d", &salary2);
	printf("Enter Employee3 monthly salary:");
	scanf("%d", &salary3);
	printf("Enter Employee4 monthly salary:");
	scanf("%d", &salary4);
	printf("Enter Employee5 monthly salary:");
	scanf("%d", &salary5);
	
	
	
	printf("\n-----------------------------------------------------------");
	
	
	averagesalary=(salary1+salary2+salary3+salary4+salary5)/5;
	
	totalsalary=salary1+salary2+salary3+salary4+salary5;
	
	
	
	printf("\nAverage salary:%d", averagesalary);
	printf("\nTotal salary%d", totalsalary);
}
