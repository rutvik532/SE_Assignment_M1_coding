/*5. Find Area of Cube formula : a = 6a2 */
#include<stdio.h>
main()
{

int a,Area;
printf("Enter the value of a:");
scanf("%d", &a);
Area=6*a*a;
printf("Cube area=%d", Area);

}
