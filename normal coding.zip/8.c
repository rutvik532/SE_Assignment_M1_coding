/*8. Find circumference of Rectangle formula : C = 4 * a */

#include<stdio.h>
main()
{
	float a,c;
	
	printf("Enter  the value of a:");
	scanf("%f", &a);
	
	c=4*a;
	
	printf("circumference of Rectangle:%.2f",c);
	
}
