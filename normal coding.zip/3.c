/*3.WAP to Find Area And Circumference of Circle */

#include<stdio.h>
main()
{
	float pi,r;
	
	pi= 3.14;
	r=8;
	
	float Area =pi*r;
	
	printf("Area of circle=%.2f", Area);
	
	
}
