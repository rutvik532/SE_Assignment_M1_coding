/*11. Find circumference of square formula : C = 4 * a */

#include<stdio.h>
main()
{
	int a,C;
	printf("Enter the value of a:");
	scanf("%d", &a);
	
	C= 4*a;
	printf("circumference of square:%d",C);
	
}
