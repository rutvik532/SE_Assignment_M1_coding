/*29. Convert minutes into seconds and hours*/

#include<stdio.h>

main()

{
	
	double minutes,seconds,hours;
	
	printf("Enter the minutes:");
	scanf("%lf", &minutes);
	
	seconds=minutes*60;
	hours=minutes/60;
	
	printf("Seconds:%.2lfsec.", seconds);
	printf("\nHours:%.2lfhr", hours);
	
	
}
