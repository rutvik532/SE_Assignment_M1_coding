/*28. Convert years into days and months */

#include<stdio.h>
main()
{
	
	int year,days;
	
	printf("Enter the year:");
	scanf("%d", &year);
	
	days=year*365;
	
	printf("Days:%d", days);
	
	
}
