/*1. Display This Information using printf 
a. Your Name 
b. Your Birth date 
c. Your Age 
d. Your Address */

#include<stdio.h>
main()
{
	
	
	printf("Name=Rutvik savaliya");
	printf("\nBirthdate=05.03.2002");
	printf("\nAge=23");
	printf("\nAddress=Nornenstrasse 4,nuremberg 90461");
	
}
