/*Find area of Rectangle Formula : A=wl */
#include<stdio.h>
main()
{
	int w,l,A;
	
	printf("Enter the Value of W:");
	scanf("%d", &w);
	
	printf("Enter the value of l:");
	scanf("%d", &l);
	
	A=w*l;
	
	printf("Rectangular Area:%d",A);
}
