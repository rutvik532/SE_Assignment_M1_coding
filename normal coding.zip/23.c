/*23. WAP to calculate swap 2 numbers with using of multiplication and division. */

#include<stdio.h>

main()

{
	int a,b;
	
	printf("Enter the number a:");
	scanf("%d", &a);
	
	printf("Enter the number b:");
	scanf("%d", &b);
	
	
	a=a*b;
	b=a/b;
	a=a/b;
	
	printf("Number a:%d",a);
	printf("\nNumber b:%d",b);
	
	
	
}
