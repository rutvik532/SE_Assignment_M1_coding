 /*Accept number of students from user. I need to give 5 apples to each 
student. How many apples are required? */

#include<stdio.h>
main()
{
	int student,total;
	
	printf("Enter number of student");
	scanf("%d", &student);
	
	total= 5*student;
	
	printf("Number of require apple:%d", total);
	
}
