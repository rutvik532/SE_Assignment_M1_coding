/*27. Convert days into months*/

#include<stdio.h>
main()

{
	
	float days,months;
	
	printf("Enter days:");
	scanf("%f", &days);
	
	
	months=days/30;
	
	printf("Months:%.2f", months);
	
}
