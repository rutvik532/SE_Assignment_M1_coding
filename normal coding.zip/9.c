/*Find circumference of Triangle formula :  triangle = a + b + c */
#include<stdio.h>
main ()
{
	int a,b,c,triangle;
	printf("Enter the value of A:");
	scanf("%d", &a);
		printf("Enter the value of B:");
	scanf("%d", &b);
		printf("Enter the value of C:");
	scanf("%d", &c);
	
	triangle= a+b+c;
	
	printf("circumference of Triangle formula:%d", triangle);
	
	
}
	
	

