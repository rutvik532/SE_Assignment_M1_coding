/*26. Convert temperature Fahrenheit to Celsius*/

#include<stdio.h>
main()
{
	float fahrenheit,celsius;
	
	printf("Enter temperature in fahrenheit:");
	scanf("%f", &fahrenheit);
	
	
	celsius=fahrenheit*(-17.22);
	printf("Celsius:%.2f", celsius);
}
