/*6. Find area of Triangle Formula : A = 1/2 � b � h */

#include<stdio.h>
main()
{
	float b,h;
	
	printf("Enter the value of b:");
	scanf("%f", &b);
	printf("\nEnter the value of h:");
	scanf("%f", &h);
	
	float Area=(b*h)/2;
	printf("\nTriangle Area:%.2f",Area);
		
	

	
}
