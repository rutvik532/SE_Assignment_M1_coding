/*2. Write a program to make Simple calculator (to make addition, subtraction, 
multiplication, division and modulo) */

#include<stdio.h>
main()
{
	float a,b,c;
	
	a=35;
	b=20;
	
	printf("a=35");
	printf("\nb=20");
	c=a+b;
	printf("\nAddition=%.2f", c);
	
	c=a-b;
	printf("\nSubstraction=%.2f", c);
	
	c=a*b;
	printf("\nMultiplicarion=%.2f", c);
	
	c=  a/b;
	printf("\nDivided=%.2f", c);	
	
}
