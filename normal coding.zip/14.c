/*14.Find ascii value of given number */

#include<stdio.h>
main()

{
	char a;
	
	printf("Enter any character:");
	scanf("%c", &a);
	
	printf("ascii value of given character:%d", a);
	
}
