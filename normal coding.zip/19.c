/*19. Calculate compound interest */

#include<stdio.h>
main ()

{


	float amount,intrest,time,totalamount;
	
	printf("Enter the amount for interest calculation:");
	scanf("%f", &amount);
	
	printf("Enter the time for interest calculation:");
	scanf("%f", &time);
	
	printf("Enter the interest rate:");
	scanf("%f", &intrest);
	
	
	
	totalamount =amount* ( pow(1+intrest/100) ,time);
	
	
	printf("%f", totalamount);
	
	
	
	
	

	
	
}
