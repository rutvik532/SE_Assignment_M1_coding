/*21. Accept 2 numbers from user and swap 2 numbers with using 3rd variable 
and without using 3rd variable */

#include<stdio.h>
main()

{
	
	int a,b,c;
	
	printf("Enter number a:");
	scanf("%d", &a);
	
	printf("Enter number b:");
	scanf("%d", &b);
	
	printf("\nNumber a:%d",a);
	printf("\nNumber b:%d",b);
	
	
	    c=a;
		a=b;
		b=c;
		
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		
		printf("\n\nNumbera:%d",a);
		printf("\nNumberb:%d",b);
}
