/*16. Convert country�s name in abbreviate form*/

#include<stdio.h>
main()
{
	char str[25] ="United State";
	
	printf("%s", str);
	
	printf("\nAbbreviated country name: %c.%c", str[0], str[7]);
	
}
