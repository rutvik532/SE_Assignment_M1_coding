/*30. WAP to convert years into days and days into years*/

#include<stdio.h>
main()

{
	int year,days,choice;
	
	printf("Enter the years:");
	scanf("%d", &year);
	
	printf("Enter the days:");
	scanf("%d", &days);
	printf("---------------------------------------------");
	printf("\nchoice1=convet year into days:");
	printf("\nchoice2=convert days into year:");
	
	printf("\n---------------------------------------------");
	printf("\nChoose your choice:");
	scanf("%d", &choice);
	
	
	
	
	switch(choice)
	
	{
		
		case  1:
		printf("\nDays:%d", year*365);
		break;
		
		case 2 :
		printf("\nYear:%d", days/365);
		break;
		
		default :
		printf("Enter invalid choice");
		break;
		
	}
	
}
